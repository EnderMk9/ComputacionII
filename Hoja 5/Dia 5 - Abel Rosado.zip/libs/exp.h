double exp (double x){
    int i = 1;
    double sum = 1.0;
    double ex  = 1.0;
    while (sum > 0.00001){
        sum = sum*x/i;
        ex += sum;
        i++;
    }
    return ex;
}