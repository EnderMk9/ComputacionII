// library for dealing with functions, evaluations, definitions, etc

// function to evaluate a single variable function in an interval with d intervals, d+1 divisions
// double t [d+1] {}; double y [d+1] {}; are requiered to be defined previously and passed as an imput
// there is no return because arrays are directly modified in memory inside functions
void eval(double (*f)(double), double x0, double xf, int d,double x[], double y[]){
    double step = (xf-x0)/d;
    for (int i = 0; i <= d; i++){
        x[i] = x0+i*step;
        y[i] = f(x0+i*step);
    }
}