g++ -std=c++17 ARP_E1.cpp -o ARP_E1
g++ -std=c++17 ARP_E2.cpp -o ARP_E2
