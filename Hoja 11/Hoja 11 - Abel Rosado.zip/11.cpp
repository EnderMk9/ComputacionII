#include "libs/header.hpp"

Matrix A = {{1,1,1},
            {1,1,1},
            {1,1,2}};

int main(){
    int k{}; Matrix U;
    Matrix D = JacobiDiag(A, U, k, 1e-10);
    coutmat(D,5); coutmat(U,5);
}